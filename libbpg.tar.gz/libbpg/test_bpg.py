# # from ctypes import *
# import ctypes
# # so_file = "test.so"
# # my_functions = CDLL(so_file)

# # print(type(my_functions))
# # print(my_functions.square(10))
# pointers = [ctypes.addressof(ctypes.create_string_buffer(8)) for i in range(4)]

# print(pointers)



# print(lib._FuncPtr)
# string_buffers = [ctypes.create_string_buffer(8) for i in range(4)]
# pointers = (ctypes.c_char_p*4)(*map(ctypes.addressof, string_buffers))
# print(pointers)
# # lib.test(pointers)
# # results = [s.value for s in string_buffers]
# # print(results)

import torch
import subprocess
import sys
import time
from subprocess import Popen, PIPE
import ctypes
from PIL import Image
import numpy as np
from torchvision.transforms.functional import to_tensor, to_pil_image
from torchvision.utils import save_image

# prepare functions
lib = ctypes.CDLL("bpgenc.so")
lib2 = ctypes.CDLL("bpgdec.so")
bpg_encode_bytes = lib.bpg_encode_bytes
bpg_decode_bytes = lib2.bpg_decode_bytes
get_buf = lib.get_buf
get_buflen = lib.get_buf_length
free_mem = lib.free_memory
get_buf.restype = ctypes.POINTER(ctypes.c_char)
bpg_decode_bytes.restype = ctypes.POINTER(ctypes.c_char)

def bpg_encode(img):
    frame = (torch.clamp(img, min = 0, max = 1) * 255).round().byte()
    _, h, w = frame.shape
    frame2 = frame.permute((1, 2, 0)).flatten()
    bs = frame2.numpy().tobytes()
    ubs = (ctypes.c_ubyte * len(bs)).from_buffer(bytearray(bs))
    bpg_encode_bytes(ubs, h, w)
    buflen =  get_buflen()
    buf = get_buf()
    bpg_stream = ctypes.string_at(buf, buflen)
    free_mem(buf)
    # breakpoint()
    return bpg_stream, h, w, len(bpg_stream)


def bpg_decode(bpg_stream, h, w):
    # breakpoint()
    ub_result = (ctypes.c_ubyte * len
    (bpg_stream)).from_buffer(bytearray(bpg_stream))
    rgb_decoded = bpg_decode_bytes(ub_result, len(bpg_stream), h, w)
    b = ctypes.string_at(rgb_decoded, h * w * 3)
    bytes = np.frombuffer(b, dtype=np.byte).reshape((h, w, 3))
    image = torch.tensor(bytes).permute((2, 0, 1)).byte().float()
    image = image / 255
    free_mem(rgb_decoded)
    return image

w, h = 128, 128
# w, h = 1280, 768

name = "128.png"
# name = "003.png"
# name = "003_extra_small.png"
img = Image.open(name).convert("RGB").resize((w, h))
img = to_tensor(img)


for it in range(100):
    st = time.perf_counter()
    bpg_stream, h, w, l = bpg_encode(img)
    ed = time.perf_counter()
    print("Encoder:", (ed - st) * 1000)
  


for it in range(100):
    st = time.perf_counter()
    image = bpg_decode(bpg_stream, h, w)
    ed = time.perf_counter()
    print("Decoder:", (ed - st) * 1000)


save_image(image, "good.png")