#include <png.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std;

int main(void) {
    // Set up input file to read from stdin
    FILE *fp = stdin;

    // Read PNG signature
    png_byte sig[8];
    fread(sig, 1, 8, fp);
    if (!png_check_sig(sig, 8)) {
        fprintf(stderr, "Error: Not a PNG file.\n");
        exit(1);
    }

    // Initialize PNG structure and read info
    png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (!png_ptr) {
        fprintf(stderr, "Error: png_create_read_struct failed.\n");
        exit(1);
    }

    png_infop info_ptr = png_create_info_struct(png_ptr);
    if (!info_ptr) {
        png_destroy_read_struct(&png_ptr, NULL, NULL);
        fprintf(stderr, "Error: png_create_info_struct failed.\n");
        exit(1);
    }

    png_infop end_info = png_create_info_struct(png_ptr);
    if (!end_info) {
        png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
        fprintf(stderr, "Error: png_create_info_struct failed.\n");
        exit(1);
    }

    png_init_io(png_ptr, fp);
    png_set_sig_bytes(png_ptr, 8);
    png_read_info(png_ptr, info_ptr);

    // Read image data
    png_uint_32 width = png_get_image_width(png_ptr, info_ptr);
    png_uint_32 height = png_get_image_height(png_ptr, info_ptr);
    png_uint_32 row_bytes = png_get_rowbytes(png_ptr, info_ptr);
    png_byte color_type = png_get_color_type(png_ptr, info_ptr);
    png_byte bit_depth = png_get_bit_depth(png_ptr, info_ptr);

    png_bytep *row_pointers = (png_bytep*) malloc(sizeof(png_bytep) * height);
    for (png_uint_32 i = 0; i < height; i++) {
        row_pointers[i] = (png_byte*) malloc(row_bytes);
    }
    png_read_image(png_ptr, row_pointers);
    cout << "going through!!" << endl;

    // Clean up
    for (png_uint_32 i = 0; i < height; i++) {
        free(row_pointers[i]);
    }
    free(row_pointers);

    png_destroy_read_struct(&png_ptr, &info_ptr, &end_info);

    return 0;
}