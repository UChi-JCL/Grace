# # from ctypes import *
# import ctypes
# # so_file = "test.so"
# # my_functions = CDLL(so_file)

# # print(type(my_functions))
# # print(my_functions.square(10))
# pointers = [ctypes.addressof(ctypes.create_string_buffer(8)) for i in range(4)]

# print(pointers)



# print(lib._FuncPtr)
# string_buffers = [ctypes.create_string_buffer(8) for i in range(4)]
# pointers = (ctypes.c_char_p*4)(*map(ctypes.addressof, string_buffers))
# print(pointers)
# # lib.test(pointers)
# # results = [s.value for s in string_buffers]
# # print(results)

import torch
import subprocess
import sys
import time
from subprocess import Popen, PIPE
import ctypes
from PIL import Image
import numpy as np
from torchvision.transforms.functional import to_tensor, to_pil_image
from torchvision.utils import save_image

# prepare functions
lib = ctypes.CDLL("bpgenc.so")
lib2 = ctypes.CDLL("bpgdec.so")
bpg_encode_bytes = lib.bpg_encode_bytes
bpg_decode_bytes = lib2.bpg_decode_bytes
get_buf = lib.get_buf
get_buflen = lib.get_buf_length
free_mem = lib.free_memory
get_buf.restype = ctypes.POINTER(ctypes.c_char)
bpg_decode_bytes.restype = ctypes.POINTER(ctypes.c_char)


def bpg_encode(frame):
    _, h, w = frame.shape
    frame2 = frame.permute((1, 2, 0)).flatten()
    bs = frame2.numpy().tobytes()
    ubs = (ctypes.c_ubyte * len(bs)).from_buffer(bytearray(bs))
    bpg_encode_bytes(ubs, h, w)
    buflen =  get_buflen()
    buf = get_buf()
    b_result = ctypes.string_at(buf, buflen)
    # free_mem(buf)
    return b_result, h, w, buflen

def bpg_decode(code, h, w):
    ub_result = (ctypes.c_ubyte * len(code)).from_buffer(bytearray(code))

    rgb_decoded = bpg_decode_bytes(ub_result, len(code), h, w)

    # lib2.simple_decode(0, 0, 128, 128)


    # with open("out.rgb", "rb") as image:
    #   f = image.read()
    #   b = bytearray(f)

    b = ctypes.string_at(rgb_decoded, h * w * 3)
    # ed = time.perf_counter()
    bytes = np.frombuffer(b, dtype=np.byte).reshape((h, w, 3))
    print(bytes.shape)
    image = torch.tensor(bytes).permute((2, 0, 1)).byte().float()
    image = image / 255
    # free_mem(rgb_decoded)
    return image

# w = 1280
# h = 768
# img_name = "003.png"
# # img_name = "128.png"
# img = Image.open(img_name).convert("RGB").resize((w, h))
# # img = Image.open(img_name).convert("RGB").resize((w, h))
# img = to_tensor(img)
# frame = (torch.clamp(img, min = 0, max = 1) * 255).round().byte()

# for i in range(1):
#     st = time.perf_counter()

#     ed = time.perf_counter()
#     print("Encoder: ", (ed - st) * 1000)


# # b_result = ctypes.c_char_p.from_buffer(result)

# # print(lib.buf_pos)


# # stdout = bpg_decode2(b_result, 128, 128)


# # print(len(b_result))
# # # print(functions)

# # print("before decode")
# # # print(ubs)

# # # get_buflen

# # bytes = np.frombuffer(stdout, dtype=np.byte).reshape((h, w, 3))


# # bytes = bpg_decode(r)

# # print({"len buff: ", len(b_result)})
# # rgbstream = bpg_decode(ub_result, buflen, 128, 128)
# # bytes = np.frombuffer(rgbstream, dtype=np.byte).reshape((h, w, 3))
# # image = torch.tensor(bytes).permute((2, 0, 1)).byte().float()
# # image = image / 255

# save_image(img, "good.png")



w, h = 128, 128

# name = "128.png"
name = "003.png"
# name = "003_extra_small.png"
img = Image.open(name).convert("RGB").resize((w, h))
img = to_tensor(img)


for it in range(1):
   bpg_stream, h, w, l = bpg_encode(img)
   print("len:", l, len(bpg_stream))
  

# in_file = open("tmp.bpg", "rb") # opening for [r]eading as [b]inary
# data = in_file.read()

for it in range(1):
  image = bpg_decode(bpg_stream, h, w)
#   image = bpg_decode(data, h, w)

print(len(bpg_stream))

save_image(image, "good.png")
