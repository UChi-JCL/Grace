# import Image

import subprocess
import sys
import time
import io
from PIL import Image
import torch
from torchvision.transforms.functional import to_tensor, to_pil_image
import torch.nn.functional as F
import imageio
import numpy as np
from torchvision.utils import save_image


def tensor_to_png_bytearray(rgb_tensor):
    rgb_tensor = rgb_tensor.cpu().detach()
    rgb_array = (rgb_tensor.permute(1, 2, 0).numpy() * 255).astype('uint8')
    # img = Image.fromarray(rgb_array)
    png_bytestream = io.BytesIO()
    # img.save(png_bytestream, 'PNG')
    imageio.imwrite(png_bytestream, rgb_array, format='png')
    png_bytestream.seek(0)
    png_bytearray = bytearray(png_bytestream.getvalue())
    return png_bytearray


def png_bytearray_to_bpg_bytearray(pngbytes):
    process = subprocess.Popen(['./bpgenc', '-'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    stdout, stderr = process.communicate(input=pngbytes)
    return stdout
# w, h = 1280, 768
# w, h = 320, 256
w, h = 128, 128


name = "128.png"
img = to_tensor(Image.open(name).convert("RGB").resize((w, h)))

# pri
# with open('output.png', 'wb') as f:
#     f.write(pngbytes)

# name = "003_small.png"
# name = "003_extra_small.png"
# png_bytestream = io.BytesIO()

# Save the image as a PNG to the BytesIO object
# img.save(png_bytestream, 'PNG')
# print(png_bytestream)
# with open(name, "rb") as image:
#   f = image.read()
#   b = bytearray(f)
  # print(b[0:10])


print(img.shape)

# print("waht ", b"".join(b))
# Start the subprocess and pass the byte array as input
# process = subprocess.Popen(, input=b)
# result = subprocess.run(['./bpgenc', '-'], input=b)


for it in range(1):
  st = time.perf_counter()
  img2 = (torch.clamp(img, min = 0, max = 1) * 255).round().byte()
  img2 = img2.permute((1, 2, 0)).flatten()
  b = img2.numpy().tobytes() 
  # with open("128.rgb", "wb") as file:
  #    file.write(b)
  ed = time.perf_counter()
  print("tensor to bytes:", (ed - st) * 1000)

  st = time.perf_counter()
  stdout = png_bytearray_to_bpg_bytearray(b)
  ed = time.perf_counter()
  print("png to bpg:", (ed - st) * 1000)
  # print(len(stdout))
  # print(stderr)

bpg_stream = stdout


for it in range(1):
  st = time.perf_counter()
  process2 = subprocess.Popen(['./bpgdec', '-'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
  stdout, stderr = process2.communicate(input=bpg_stream)
  print(len(stdout))
  print(stderr)
  ed = time.perf_counter()
  bytes = np.frombuffer(stdout, dtype=np.byte).reshape((128, 128, 3))
  print(bytes.shape)
  image = torch.tensor(bytes).permute((2, 0, 1)).byte().float()
  image = image / 255
  print("decoder:", (ed - st) * 1000)

print(len(stdout))
save_image(image, "img.png")

# with open("out2.png", "wb") as image:
#     # Write bytes to file
#     image.write(stdout)

# for it in range(50):
#   start = time.perf_counter()
#   process = subprocess.Popen(['./bpgenc', '-'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
#   stdout, stderr = process.communicate(input=b)
#   print(len(stdout))
#   print(stderr)
#   end = time.perf_counter()
#   print((end - start) * 1000)
# out = process.communicate(input=b)[0]

# with open("003.png", "rb") as image:
#     # f = image.read()
#     process = subprocess.Popen(['./bpgenc', '003.png'], 
#         stdin=image, stdout=sys.stdout, stderr=sys.stderr)
    
# process.stdin.write(b)
# process.stdin.close()
# process.stdin.write(b)
# process.stdin.close()