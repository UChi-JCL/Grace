# import Image

import subprocess
import sys
import time
import io
from PIL import Image
import torch
from torchvision.transforms.functional import to_tensor, to_pil_image
import torch.nn.functional as F
import imageio
import numpy as np
from torchvision.utils import save_image



def bpg_encode(frame):
    """
    Input:
        frame: the image tensor (3, h, w)
    Output:
        the bpg byte stream, h, w, length of the stream


    """
    st = time.perf_counter()
    frame = (torch.clamp(frame, min = 0, max = 1) * 255).round().byte()
    _, h, w = frame.shape
    frame = frame.permute((1, 2, 0)).flatten()
    b = frame.numpy().tobytes()
    ed = time.perf_counter()
    print("tensor to bytes:", (ed - st) * 1000)

    st = time.perf_counter()
    process = subprocess.Popen(['./bpgenc', str(h), str(w)], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    bpg_stream, stderr = process.communicate(input=b)
    ed = time.perf_counter()
    print("png to bpg:", (ed - st) * 1000)
    return bpg_stream, h, w, len(bpg_stream)

def bpg_decode(code, h, w):
    st = time.perf_counter()
    process2 = subprocess.Popen(['./bpgdec', '-'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    stdout, stderr = process2.communicate(input=code)
    print(len(stdout))
    print(stderr)
    ed = time.perf_counter()
    bytes = np.frombuffer(stdout, dtype=np.byte).reshape((h, w, 3))
    print(bytes.shape)
    image = torch.tensor(bytes).permute((2, 0, 1)).byte().float()
    image = image / 255
    print("decoder:", (ed - st) * 1000)
    return image

# w, h = 1280, 768
# w, h = 320, 256
w, h = 128, 128

name = "128.png"
# name = "003.png"
# name = "003_extra_small.png"
img = Image.open(name).convert("RGB").resize((w, h))
img = to_tensor(img)


for it in range(1):
   bpg_stream, h, w, l = bpg_encode(img)
  #  print("len:", l, len(bpg_stream))
  

for it in range(1):
  image = bpg_decode(bpg_stream, h, w)

print(len(bpg_stream))

save_image(image, "img4.png")
