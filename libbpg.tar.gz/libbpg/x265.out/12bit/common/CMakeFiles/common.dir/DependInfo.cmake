# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM_YASM"
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM_YASM
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/blockcopy8.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/blockcopy8.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/const-a.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/const-a.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/cpu-a.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/cpu-a.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/dct8.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/dct8.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/intrapred16.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/intrapred16.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/ipfilter16.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/ipfilter16.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/loopfilter.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/loopfilter.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/mc-a.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/mc-a.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/mc-a2.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/mc-a2.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/pixel-a.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/pixel-a.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/pixel-util8.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/pixel-util8.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/pixeladd8.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/pixeladd8.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/sad16-a.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/sad16-a.asm.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/ssd-a.asm" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/ssd-a.asm.o"
  )
set(CMAKE_ASM_YASM_COMPILER_ID "YASM")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM_YASM
  "EXPORT_C_API=1"
  "HAVE_INT_TYPES_H=1"
  "HAVE_LIBNUMA"
  "HIGH_BIT_DEPTH=1"
  "X265_ARCH_X86=1"
  "X265_DEPTH=12"
  "X265_NS=x265"
  "X86_64=1"
  "__STDC_LIMIT_MACROS=1"
  )

# The include file search paths:
set(CMAKE_ASM_YASM_TARGET_INCLUDE_PATH
  "/usr/include"
  "/mnt/data/ziyizhang/libbpg/x265/source/."
  "/mnt/data/ziyizhang/libbpg/x265/source/common"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder"
  "."
  )
set(CMAKE_DEPENDS_CHECK_CXX
  "/mnt/data/ziyizhang/libbpg/x265/source/common/bitstream.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/bitstream.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/common.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/common.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/constants.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/constants.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/cpu.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/cpu.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/cudata.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/cudata.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/dct.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/dct.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/deblock.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/deblock.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/frame.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/frame.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/framedata.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/framedata.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/intrapred.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/intrapred.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/ipfilter.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/ipfilter.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/loopfilter.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/loopfilter.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/lowres.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/lowres.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/md5.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/md5.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/param.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/param.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/piclist.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/piclist.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/picyuv.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/picyuv.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/pixel.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/pixel.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/predict.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/predict.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/primitives.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/primitives.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/quant.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/quant.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/scalinglist.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/scalinglist.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/shortyuv.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/shortyuv.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/slice.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/slice.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/threading.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/threading.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/threadpool.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/threadpool.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/vec/dct-sse3.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/vec/dct-sse3.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/vec/dct-sse41.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/vec/dct-sse41.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/vec/dct-ssse3.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/vec/dct-ssse3.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/vec/vec-primitives.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/vec/vec-primitives.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/version.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/version.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/wavefront.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/wavefront.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/x86/asm-primitives.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/x86/asm-primitives.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/common/yuv.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/12bit/common/CMakeFiles/common.dir/yuv.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "EXPORT_C_API=1"
  "HAVE_INT_TYPES_H=1"
  "HAVE_LIBNUMA"
  "HIGH_BIT_DEPTH=1"
  "X265_ARCH_X86=1"
  "X265_DEPTH=12"
  "X265_NS=x265"
  "X86_64=1"
  "__STDC_LIMIT_MACROS=1"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/mnt/data/ziyizhang/libbpg/x265/source/."
  "/mnt/data/ziyizhang/libbpg/x265/source/common"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder"
  "."
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
