# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/analysis.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/analysis.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/api.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/api.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/bitcost.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/bitcost.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/dpb.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/dpb.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/encoder.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/encoder.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/entropy.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/entropy.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/frameencoder.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/frameencoder.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/framefilter.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/framefilter.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/level.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/level.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/motion.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/motion.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/nal.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/nal.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/ratecontrol.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/ratecontrol.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/reference.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/reference.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/sao.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/sao.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/search.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/search.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/sei.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/sei.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/slicetype.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/slicetype.cpp.o"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder/weightPrediction.cpp" "/mnt/data/ziyizhang/libbpg/x265.out/8bit/encoder/CMakeFiles/encoder.dir/weightPrediction.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "EXPORT_C_API=1"
  "HAVE_INT_TYPES_H=1"
  "HAVE_LIBNUMA"
  "HIGH_BIT_DEPTH=0"
  "X265_ARCH_X86=1"
  "X265_DEPTH=8"
  "X265_NS=x265"
  "X86_64=1"
  "__STDC_LIMIT_MACROS=1"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/mnt/data/ziyizhang/libbpg/x265/source/."
  "/mnt/data/ziyizhang/libbpg/x265/source/common"
  "/mnt/data/ziyizhang/libbpg/x265/source/encoder"
  "."
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
