#include <cstdio>
#include <iostream>
#include <png.h>
using namespace std;

// const int L = 961754;
const int L = 961754;


unsigned char buf[L];
int main() {
    FILE *f = stdin;
#ifdef PNG_STDIO_SUPPORTED
    cout << "supported" << endl;
#endif
    printf("%ld\n", fread(buf, 1, L, f));
    long long x = 0;
    for (int i = 0; i < L; i++) {
        x = (x * 10 + buf[i]);
    }
    // cout << endl;
    cout << x << endl;
    printf("%s\n", buf);
}